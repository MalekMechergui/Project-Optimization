function [ Z ] = c( x,y )
%la contrainte d'egalit� (un cercle)
Z=x.^2+y.^2-16;
end

